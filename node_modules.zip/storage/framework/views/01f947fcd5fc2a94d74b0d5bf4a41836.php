<nav class="navbar navbar-expand-lg bg-light navbar-light py-3 py-lg-0 px-0 px-lg-5">
    <div class="container">
        <a class="navbar-brand font-weight-bold text-secondary" style="font-size: 43px;" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('storage/img/logo.png')); ?>" alt="Logo" class="img-fluid mr-2" style="max-height: 50px;">
            <span class="text-primary"> <?php echo e(config('app.name', 'Laravel')); ?></span>
           
        </a>
        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

  
        <div class="collapse navbar-collapse justify-content-between" id="#navbarSupportedContent">
            <!-- Left Side Of Navbar -->
        <div class="navbar-nav font-weight-bold mx-auto py-0">   
            <ul class="navbar-nav me-auto">
              <li class="nav-item-active"><a class="nav-link" href="/">Home</a></li>
              <li class="nav-item"><a class="nav-link" href="/about">About</a></li>
              <li class="nav-item"><a class="nav-link" href="/services">Services</a></li>
              <li class="nav-item"><a class="nav-link" href="/blog">Blog</a></li>
            </ul>
        </div> 
  
    
  
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ms-auto">

                
                
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="btn " href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                        </li>

                    <?php endif; ?>
  
                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="btn btn-primary px-4" href="/contact"><?php echo e(__('Join Us')); ?></a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>
  
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="/dashboard">Dashboard</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>
  
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                    
                <?php endif; ?>
            </ul>
        </div>
    </div>
  </nav><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/inc/navbar.blade.php ENDPATH**/ ?>