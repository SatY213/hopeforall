
<?php $__env->startSection('content'); ?>
  
  <h1><?php echo e($post->title); ?></h1>
  <div class ="col-md-6 col-sm-4">
    <img style="width:100%" src="/storage/cover_image/<?php echo e($post->cover_image); ?>">
  </div>
              
  <div>
    <?php echo e($post->body); ?>

  </div>

  <hr>
  <small style="margin-left: 1rem;margin-bottom:0.5rem">Written on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>

  <hr>
  <?php if(!Auth::guest()): ?>
  <?php if(Auth::user()->id == $post->user_id): ?>
  <div class="d-flex">
    <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-secondary">Edit</a>

    <!-- Destroy Form -->
    <?php echo Form::open(['route' => ['posts.destroy', $post->id], 'method' => 'POST', 'onsubmit' => 'return confirm("Are you sure you want to delete this post?");']); ?>

        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger mx-2'])); ?>

    <?php echo Form::close(); ?>


    <a href="/posts" class="btn btn-default mx-2">Go back</a>
</div>
      
  <?php endif; ?>    
  <?php endif; ?>
  


<?php $__env->stopSection(); ?>               

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/posts/show.blade.php ENDPATH**/ ?>