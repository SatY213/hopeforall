

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container" style="margin-left: 6cm;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3>Users</h3></div>
                    <div class="panel-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>isadmin</th>
                                    <th>Created at</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->isadmin); ?></td>
                                    <td><?php echo e($user->created_at); ?></td>
                                    <td>
                                        <div style="display: flex; ">
                                            <button type="button" class="btn btn-info mr-2" data-toggle="modal" data-target="#user<?php echo e($user->id); ?>">Detail</button>
                                            <div style="width: 10px;"></div>
                                            <form method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary">Edit</a>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <!-- Modal -->
                                <div class="modal fade" id="user<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="user<?php echo e($user->id); ?>Label" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="user<?php echo e($user->id); ?>Label"><?php echo e($user->name); ?></h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>Name:</strong> <?php echo e($user->name); ?></p>
                                                <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
                                                <p><strong>Isadmin:</strong> <?php echo e($user->isadmin); ?></p>
                                                <p><strong>Created at:</strong> <?php echo e($user->created_at); ?></p>
                                            </div>
                                            <div class="modal-footer">
                                                <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-info mr-2">Show</a>

                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <a href="<?php echo e(route('users.create')); ?>" class="btn btn-success">Add User</a>
                        <a href="/dashboard" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>        
   
    <!-- <script>
    // Show confirmation message before deleting a needer
    $('form').submit(function (event) {
    var form = this;
    event.preventDefault();
    swal({
    title: "Are you sure?",
    text: "Once deleted, you will not be able to recover this needer!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
    })
    .then((willDelete) => {
    if (willDelete) {
    form.submit();
    } else {
    swal("The needer is safe!");
    }
    });
    });
    </script>
-->
   
    
    
    
    
    
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/users/index.blade.php ENDPATH**/ ?>