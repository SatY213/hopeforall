

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid" style="margin-left: 6cm;">
    <div class="row">
        <div class="col-md-3 sidebar-container">
          <div class="panel panel-default">
            <div class="panel-heading"><h3>Make a Donation<h3></div>
            <div class="panel-body">
              <?php echo Form::open(['route' => 'donation.store', 'class' => 'form-horizontal']); ?>

              <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                <?php echo Form::label('name', 'Name', ['class' => 'control-label']); ?>

                <?php echo Form::text('name', old('name'), ['class' => 'form-control', 'required' => 'required']); ?>

                <?php if($errors->has('name')): ?>
                  <span class="help-block">
                    <strong><?php echo e($errors->first('name')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
              <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                <?php echo Form::label('email', 'Email Address', ['class' => 'control-label']); ?>

                <?php echo Form::email('email', old('email'), ['class' => 'form-control', 'required' => 'required']); ?>

                <?php if($errors->has('email')): ?>
                  <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
              <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
                <?php echo Form::label('amount', 'Donation Amount', ['class' => 'control-label']); ?>

                <?php echo Form::number('amount', old('amount'), ['class' => 'form-control', 'required' => 'required', 'step' => '0.01']); ?>

                <?php if($errors->has('amount')): ?>
                  <span class="help-block">
                    <strong><?php echo e($errors->first('amount')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
              <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
                <?php echo Form::label('message', 'Message (optional)', ['class' => 'control-label']); ?>

                <?php echo Form::textarea('message', old('message'), ['class' => 'form-control', 'rows' => '4']); ?>

                <?php if($errors->has('message')): ?>
                  <span class="help-block">
                    <strong><?php echo e($errors->first('message')); ?></strong>
                  </span>
                <?php endif; ?>
              </div>
               <br>
               <div class="form-group">
                <?php echo Form::submit('Donate', ['class' => 'btn btn-primary']); ?>

                <?php echo Form::close(); ?>

                <a href="/boughts" class="btn btn-outline-secondary float-right ml-2">Go Back</a>
              </div>
              


            </div>
          </div>
        </div>
      </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/donation/create.blade.php ENDPATH**/ ?>