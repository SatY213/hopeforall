

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container" style="margin-left: 7cm;">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3>Edit Donation<h3></div>

                    <div class="panel-body">
                        <?php echo Form::model($donation, ['route' => ['donation.update', $donation->id], 'method' => 'PUT', 'class' => 'form-horizontal']); ?>


                            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('name', 'Name', ['class' => 'col-md-4 control-label']); ?>


                                <div class="col-md-6">
                                    <?php echo Form::text('name', null, ['class' => 'form-control', 'required' => 'required']); ?>


                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('name')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('email', 'Email Address', ['class' => 'col-md-4 control-label']); ?>


                                <div class="col-md-6">
                                    <?php echo Form::email('email', null, ['class' => 'form-control', 'required' => 'required']); ?>


                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('amount', 'Donation Amount', ['class' => 'col-md-4 control-label']); ?>


                                <div class="col-md-6">
                                    <?php echo Form::number('amount', null, ['class' => 'form-control', 'required' => 'required', 'step' => '0.01']); ?>


                                    <?php if($errors->has('amount')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('amount')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('message') ? ' has-error' : ''); ?>">
                                <?php echo Form::label('message', 'Message (optional)', ['class' => 'col-md-4 control-label']); ?>


                                <div class="col-md-6">
                                    <?php echo Form::textarea('message', null, ['class' => 'form-control', 'rows' => '4']); ?>


                                    <?php if($errors->has('message')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('message')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-4">
                                    <?php echo Form::submit('Update', ['class' => 'btn btn-primary']); ?>

                                </div>
                            </div>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/donation/edit.blade.php ENDPATH**/ ?>