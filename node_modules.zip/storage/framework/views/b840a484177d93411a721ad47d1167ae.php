

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container-fluid" style="margin-left: 6cm;">
    <div class="row">
        <div class="col-md-3 sidebar-container">
            <div class="panel panel-default">
                <div class="panel-heading"><h3>Add a Needer</h3></div>
                <div class="panel-body">
                    <?php echo Form::open(['route' => 'needers.store', 'class' => 'form-horizontal']); ?>

               
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('name', 'Name', ['class' => 'control-label']); ?>

                        <?php echo Form::text('name', old('name'), ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('email', 'Email', ['class' => 'control-label']); ?>

                        <?php echo Form::email('email', old('email'), ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('phone', 'Phone', ['class' => 'control-label']); ?>

                        <?php echo Form::text('phone', old('phone'), ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php if($errors->has('phone')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->firstf('phone')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('type') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('type', 'Type', ['class' => 'control-label']); ?>

                        <?php echo Form::select('type', ['Father' => 'Father', 'Mother' => 'Mother', 'Mother divorced', 'Father divorced' , 'Single'], old('type'), ['class' => 'form-control', 'required' => 'required', 'placeholder' => 'Select a type']); ?>

                        <?php if($errors->has('type')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('type')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('job') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('job', 'Job', ['class' => 'control-label']); ?>

                        <?php echo Form::text('job', old('job'), ['class' => 'form-control']); ?>

                        <?php if($errors->has('job')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('job')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('address', 'Address', ['class' => 'control-label']); ?>

                        <?php echo Form::text('address', old('address'), ['class' => 'form-control']); ?>

                        <?php if($errors->has('address')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('address')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                        <div class="form-group<?php echo e($errors->has('birthday') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('birthday', 'Birthday', ['class' => 'control-label']); ?>

                        <?php echo Form::date('birthday', old('birthday'), ['class' => 'form-control']); ?>

                        <?php if($errors->has('birthday')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('birthday')); ?></strong>
                        </span>
                        <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('children') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('children', 'Children', ['class' => 'control-label']); ?>

                            <?php echo Form::number('children', old('children'), ['class' => 'form-control']); ?>                            <?php if($errors->has('children')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('children')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('salary') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('salary', 'Salary', ['class' => 'control-label']); ?>

                            <?php echo Form::number('salary', old('salary'), ['class' => 'form-control']); ?>                            <?php if($errors->has('children')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('salary')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                            <?php echo Form::label('description', 'Description', ['class' => 'control-label']); ?>

                            <?php echo Form::textarea('description', old('description'), ['class' => 'form-control']); ?>                            <?php if($errors->has('children')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>



                        <br>
                        <div class="form-group">
                        <?php echo Form::submit('Add Needer', ['class' => 'btn btn-primary']); ?>

                        <a href="/needers" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </div>
                        <?php echo Form::close(); ?>

                        </div>
                        </div>
                        </div>
                        </div>
                        
                        </div>
                        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/needers/create.blade.php ENDPATH**/ ?>