<!-- resources/views/projects/edit.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Edit Project</div>
                    <div class="card-body">
                        <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="name">Name:</label>
                                <input type="text" name="name" id="name" class="form-control" value="<?php echo e($project->name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Description:</label>
                                <textarea name="description" id="description" class="form-control" required><?php echo e($project->description); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="starting_date">Starting Date:</label>
                                <input type="date" name="starting_date" id="starting_date" class="form-control" value="<?php echo e($project->starting_date); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="ending_date">Ending Date:</label>
                                <input type="date" name="ending_date" id="ending_date" class="form-control" value="<?php echo e($project->ending_date); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="budget">Budget:</label>
                                <input type="number" name="budget" id="budget" class="form-control" value="<?php echo e($project->budget); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="image">Image:</label>
                                <input type="file" name="image" id="image" class="form-control-file">
                            </div>
                            <button type="submit" class="btn btn-success">Update Project</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/projects/edit.blade.php ENDPATH**/ ?>