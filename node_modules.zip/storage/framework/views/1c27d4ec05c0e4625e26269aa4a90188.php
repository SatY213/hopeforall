

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="container" style="margin-left: 6cm;">        
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3>Needers</h3></div>
                    <div class="panel-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Date Of need</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $needers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $needer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($needer->name); ?></td>
                                    <td><?php echo e($needer->email); ?></td>
                                    <td><?php echo e($needer->created_at); ?></td>
                                    <td>
                                        <div style="display: flex; ">
                                            <button type="button" class="btn btn-info mr-2" data-toggle="modal" data-target="#needer<?php echo e($needer->id); ?>">Detail</button>
                                            <div style="width: 10px;"></div>
                                            <form method="POST" action="<?php echo e(route('needers.destroy', $needer->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href="<?php echo e(route('needers.edit', $needer->id)); ?>" class="btn btn-primary">Edit</a>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <!-- Modal -->
                                <div class="modal fade" id="needer<?php echo e($needer->id); ?>" tabindex="-1" role="dialog" aria-labelledby="needer<?php echo e($needer->id); ?>Label" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="needer<?php echo e($needer->id); ?>Label"><?php echo e($needer->name); ?></h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>Email:</strong> <?php echo e($needer->email); ?></p>
                                                <p><strong>Phone:</strong> <?php echo e($needer->phone); ?></p>
                                                <p><strong>Type:</strong> <?php echo e($needer->type); ?></p>
                                                <p><strong>Job:</strong> <?php echo e($needer->job); ?></p>
                                                <p><strong>Adresse:</strong> <?php echo e($needer->adresse); ?></p>
                                                <p><strong>Birthday:</strong> <?php echo e($needer->birthday); ?></p>
                                                <p><strong>Children:</strong> <?php echo e($needer->children); ?></p>
                                                <p><strong>Salary:</strong> <?php echo e($needer->salary); ?></p>
                                                <p><strong>Description:</strong> <?php echo e($needer->description); ?></p>
                                                <p><strong>Date Of need:</strong> <?php echo e($needer->created_at); ?></p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <a href="<?php echo e(route('needers.create')); ?>" class="btn btn-success">Add Needer</a>
                        <a href="/dashboard" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>        
   
    <!-- <script>
    // Show confirmation message before deleting a needer
    $('form').submit(function (event) {
    var form = this;
    event.preventDefault();
    swal({
    title: "Are you sure?",
    text: "Once deleted, you will not be able to recover this needer!",
    icon: "warning",
    buttons: true,
    dangerMode: true,
    })
    .then((willDelete) => {
    if (willDelete) {
    form.submit();
    } else {
    swal("The needer is safe!");
    }
    });
    });
    </script>
-->
   
    
    
    
    
    
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/needers/index.blade.php ENDPATH**/ ?>