<?php $__env->startComponent('mail::message'); ?>
# New Contact Form Submission

**Name:** <?php echo e($data['name']); ?>


**Email:** <?php echo e($data['email']); ?>


**Message:** 

<?php echo e($data['message']); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\lsapp\resources\views/emails/contact-form-submitted.blade.php ENDPATH**/ ?>