

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container" style="margin-left: 6cm;">
        <div class="row">
            <div class="col-md-12">
                <h3>Benevoles</h3>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Birthday</th>
                                    <th>Job</th>
                                    <th>Email</th>
                                    <th>Address</th>
                                    <th>Phone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $benevoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benevole): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($benevole->id); ?></td>
                                        <td><?php echo e($benevole->name); ?></td>
                                        <td><?php echo e($benevole->birthday); ?></td>
                                        <td><?php echo e($benevole->job); ?></td>
                                        <td><?php echo e($benevole->email); ?></td>
                                        <td><?php echo e($benevole->address); ?></td>
                                        <td><?php echo e($benevole->phone); ?></td>
                                        <td>
                                            <div style="display: flex;">
                                                <button type="button" class="btn btn-info mr-2" data-toggle="modal" data-target="#benevole<?php echo e($benevole->id); ?>">Details</button>
                                                <div style="width: 10px;"></div>
                                                <form method="POST" action="<?php echo e(route('benevoles.destroy', $benevole->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <a href="<?php echo e(route('benevoles.edit', $benevole->id)); ?>" class="btn btn-primary">Edit</a>
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                            </div>

                                                                                  <!-- Modal -->
                                                                                  <div class="modal fade" id="benevole<?php echo e($benevole->id); ?>" tabindex="-1" role="dialog" aria-labelledby="benevole<?php echo e($benevole->id); ?>Label" aria-hidden="true">
                                                                                    <div class="modal-dialog" role="document">
                                                                                        <div class="modal-content">
                                                                                            <div class="modal-header">
                                                                                                <h5 class="modal-title" id="benevole<?php echo e($benevole->id); ?>Label">Benevole Details</h5>
                                                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                                                    <span aria-hidden="true">&times;</span>
                                                                                                </button>
                                                                                            </div>
                                                                                            <div class="modal-body">
                                                                                                <p><strong>Name:</strong> <?php echo e($benevole->name); ?></p>
                                                                                                <p><strong>Birthday:</strong> <?php echo e($benevole->birthday); ?></p>
                                                                                                <p><strong>Job:</strong> <?php echo e($benevole->job); ?></p>
                                                                                                <p><strong>Email:</strong> <?php echo e($benevole->email); ?></p>
                                                                                                <p><strong>Address:</strong> <?php echo e($benevole->address); ?></p>    
                                                                                                <p><strong>Phone:</strong> <?php echo e($benevole->phone); ?></p>
  
                                                                                            </div>
                                
                                                                                
                                                                            
                                
                                
                                
                                
                                
                                
                                                                                            <div class="modal-footer d-flex justify-content-between">
                                                                                                <a class="btn btn-sm btn-info float-right" href="<?php echo e(route('benevoles.getProjects', ['benevole' => $benevole->id])); ?>">Get Projects</a>                                                                                                  
                                                                                                <div>
                                                                                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                                                                </div>
                                                                                              </div>
                                                                                              
                                                                                            
                                                                                        </div>
                                                                                    </div>
                                                                                </div>                
                                
                                
                                                                    </td>   
                                                                        
                                                                <!-- Project Details Modal End -->
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="float-right">
                            <a href="<?php echo e(route('benevoles.create')); ?>" class="btn btn-success">Add Benevole</a>
                            <a href="/dashboard" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </div>
                  


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/benevoles/index.blade.php ENDPATH**/ ?>