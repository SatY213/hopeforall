

<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <h1><?php echo e($project->name); ?></h1>
        <div class="row">

            <div class="col-md-6">
              <ul class="list-group">
                <li class="list-group-item"><strong>Description:</strong> <?php echo e($project->description); ?></li>
                <li class="list-group-item"><strong>Budget:</strong> <?php echo e($project->budget); ?></li>
                <li class="list-group-item"><strong>Start date:</strong> <?php echo e($project->starting_date); ?></li>
                <li class="list-group-item"><strong>End date:</strong> <?php echo e($project->ending_date); ?></li>
                <li class="list-group-item"><strong>Boughts: </strong> <button type="button" class="btn btn-success" onclick="toggleTable2()">+</button><strong> Benevoles: </strong>                 <button type="button" class="btn btn-success" onclick="toggleTable()">+</button>
                </li>
                


              </ul>
            </div>


       <?php echo $__env->make('benevoles.include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <?php echo $__env->make('boughts.include', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 


      </div>
      
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/projects/show.blade.php ENDPATH**/ ?>