

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Main Content -->
<main role="main" id ="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?>

        
                    </div>
                    <div class="card-body">
                        <h1>Posts</h1>

                        <div class="row">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-4">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($post->title); ?></h5>
                                            
                                                <img style="width:100%" src="/storage/cover_image/<?php echo e($post->cover_image); ?>">
                                            
                                            <p class="card-text"><?php echo e($post->body); ?></p>
                                            <a href="<?php echo e(route('posts.show', ['post' => $post->id])); ?>" class="btn btn-primary">Read More</a>
                                        </div>
                                        <hr>
                                        <small style="margin-left: 1rem;margin-bottom:0.5rem">Written on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
                                        
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                            <div class="col-12 d-flex ">
                                <?php echo e($posts->links('pagination::simple-bootstrap-4')); ?>

                            </div>
                        </div>
                    

    
                        <div class="panel-body" id="content-container">
                            
                            <a href="<?php echo e(route('posts.create')); ?>" class="btn btn-success">Add Post</a>

                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<style>
    .card-text {
      max-height: 4.8em; /* Adjust the height as needed */
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 4; /* Limit the content to four lines */
      -webkit-box-orient: vertical;
    }
    .card {
        height: 100%;
    }

    .image-container {
        width: 100%;
        height: 200px;
        overflow: hidden;
    }

    .card-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .card-footer-text {
        margin-left: 1rem;
        margin-bottom: 0.5rem;
    }
  </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/posts/index.blade.php ENDPATH**/ ?>