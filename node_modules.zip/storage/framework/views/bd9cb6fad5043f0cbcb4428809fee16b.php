
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<div class="container" style="margin-left: 6cm;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Create Fee')); ?></div>

                <div class="card-body">
                    <form action="<?php echo e(route('fees.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    
                        <div class="form-group">
                            <label for="member">Member</label>
                            <select class="form-control" id="member" name="member" required>
                                <option value="">Select Member</option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->name); ?>"><?php echo e($member->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    
                        <div class="form-group">
                            <label for="amount">Amount</label>
                            <input type="text" class="form-control" id="amount" name="amount" value="<?php echo e(old('amount')); ?>" required>
                        </div>
                    
                        <div class="form-group">
                            <label for="from">From</label>
                            <input type="date" class="form-control" id="from" name="from" value="<?php echo e(old('from')); ?>" required>
                        </div>
                    
                        <div class="form-group">
                            <label for="to">To</label>
                            <input type="date" class="form-control" id="to" name="to" value="<?php echo e(old('to')); ?>" required>
                        </div>
                    <br>
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <a href="/fees" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/fees/create.blade.php ENDPATH**/ ?>