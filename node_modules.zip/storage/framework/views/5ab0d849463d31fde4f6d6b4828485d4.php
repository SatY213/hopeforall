
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">Bought Item Details</div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label for="project">Project:</label>
                            <p><?php echo e($bought->project->name); ?></p>
                        </div>
                        <div class="form-group">
                            <label for="product">Product:</label>
                            <p><?php echo e($bought->product); ?></p>
                        </div>
                        <div class="form-group">
                            <label for="quantity">Quantity:</label>
                            <p><?php echo e($bought->quantity); ?></p>
                        </div>
                        <div class="form-group">
                            <label for="unit_price">Unit Price:</label>
                            <p><?php echo e($bought->unit_price); ?></p>
                        </div>
                        <a href="/boughts" class="btn btn-primary">Back</a>
                        <a href="<?php echo e(route('boughts.edit', $bought->id)); ?>" class="btn btn-primary">Edit</a>
                        <form action="<?php echo e(route('boughts.destroy', $bought->id)); ?>" method="POST" style="display: inline-block;">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('DELETE')); ?>

                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this bought item?')">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php /**PATH C:\xampp\htdocs\lsapp\resources\views/boughts/show.blade.php ENDPATH**/ ?>