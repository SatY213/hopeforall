
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container" style="margin-left: 6cm;">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3>Edit Bought</h3></div>

                    <div class="panel-body">
                        <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('boughts.update', $bought->id)); ?>">
                            <?php echo e(method_field('PUT')); ?>

                            <?php echo e(csrf_field()); ?>


                            <div class="form-group<?php echo e($errors->has('project_id') ? ' has-error' : ''); ?>">
                                <label for="project_id" class="col-md-4 control-label">Project</label>

                                <div class="col-md-6">
                                    <select name="project_id" id="project_id" class="form-control">
                                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($project->id); ?>"<?php echo e($bought->project_id == $project->id ? ' selected' : ''); ?>><?php echo e($project->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                    <?php if($errors->has('project_id')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('project_id')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('product') ? ' has-error' : ''); ?>">
                                <label for="product" class="col-md-4 control-label">Product</label>

                                <div class="col-md-6">
                                    <input id="product" type="text" class="form-control" name="product" value="<?php echo e($bought->product); ?>" required autofocus>

                                    <?php if($errors->has('product')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('product')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('quantity') ? ' has-error' : ''); ?>">
                                <label for="quantity" class="col-md-4 control-label">Quantity</label>

                                <div class="col-md-6">
                                    <input id="quantity" type="number" class="form-control" name="quantity" value="<?php echo e($bought->quantity); ?>" required>

                                    <?php if($errors->has('quantity')): ?>
                                        <span class="help-block">
                                            <strong><?php echo e($errors->first('quantity')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('unit_price') ? ' has-error' : ''); ?>">
                                <label for="unit_price" class="col-md-4 control-label">Unit Price</label>

                                <div class="col-md-6">
                                    <input id="unit_price" type="number" class="form-control" name="unit_price" value="<?php echo e($bought->unit_price); ?>" step="0.01" required>

                                    <?php if($errors->has('unit_price')): ?>
                                        <span class ="help-block">
                                            <strong><?php echo e($errors->first('unit_price')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                            </div>
                                            </div>
                                            <br>

                                            <div class="form-group">
                                                <div class="col-md-6 col-md-offset-4">
                                                    <button type="submit" class="btn btn-primary">
                                                        Update
                                                    </button>
                                                    <a href="/boughts" class="btn btn-outline-secondary float-right ml-2">Go Back</a>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<?php $__env->stopSection(); ?>                    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/boughts/edit.blade.php ENDPATH**/ ?>