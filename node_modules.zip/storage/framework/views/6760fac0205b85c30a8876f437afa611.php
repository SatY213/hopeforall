

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container" style="margin-left: 6cm;">
        <div class="row">
            <div class="col-md-12">
                <h3>Projects</h3>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Budget</th>
                                    <th>Starting Date</th>
                                    <th>Ending Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($project->name); ?></td>
                                    <td><?php echo e($project->description); ?></td>
                                    <td><?php echo e($project->budget); ?></td>
                                    <td><?php echo e($project->starting_date); ?></td>
                                    <td><?php echo e($project->ending_date); ?></td>
                                    <td>
                                        <div style="display: flex;">
                                            <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="btn btn-info mr-2">Details</a>
                                            <div style="width: 10px;"></div>
                                            <form method="POST" action="<?php echo e(route('projects.destroy', $project->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="btn btn-primary">Edit</a>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="float-right">
                            <a href="<?php echo e(route('projects.create')); ?>" class="btn btn-success">Add Project</a>
                            <a href="/dashboard" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </div>
                  
            </div>
        </div>
    </div>


    
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/projects/index.blade.php ENDPATH**/ ?>