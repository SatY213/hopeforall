<?php $__env->startComponent('mail::message'); ?>
# New Participation Form Submission

You have received a new participation form submission for the project: <?php echo e($project->name); ?>


## Details:

- Name: <?php echo e($data['name']); ?>

- Email: <?php echo e($data['email']); ?>

- Address: <?php echo e($data['address']); ?>

- Phone: <?php echo e($data['phone']); ?>

- Message: <?php echo e($data['message']); ?>


Thank you for your participation!

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\lsapp\resources\views/emails/participation_form-submitted.blade.php ENDPATH**/ ?>