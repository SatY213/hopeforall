

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container" style="margin-left: 6cm; width:15cm;">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading"><h3>Edit Benevole</h3></div>
                    <div class="panel-body">
                        <form method="POST" action="<?php echo e(route('benevoles.update', $benevole->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control" id="name" name="name" value="<?php echo e($benevole->name); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="birthday">Birthday</label>
                                <input type="date" class="form-control" id="birthday" name="birthday" value="<?php echo e($benevole->birthday); ?>" required>
                            </div>
                            <?php if($projects->count() > 0): ?>
                            <div class="form-group">
                                <label for="project_id">Project</label>
                                <select name="project_id" id="project_id" class="form-control">
                                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('project_id')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('project_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p>No projects found.</p>
                        <?php endif; ?>
                        
                            <div class="form-group">
                                <label for="job">Job</label>
                                <input type="text" class="form-control" id="job" name="job" value="<?php echo e($benevole->job); ?>" required>
                            </div>
                  
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" class="form-control" id="address" name="address" value="<?php echo e($benevole->address); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo e($benevole->email); ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="phone">Phone</label>
                                <input type="text" class="form-control" id="phone" name="phone" value="<?php echo e($benevole->phone); ?>" required>
                            </div>
                     
                            <br>
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="/benevoles" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/benevoles/edit.blade.php ENDPATH**/ ?>