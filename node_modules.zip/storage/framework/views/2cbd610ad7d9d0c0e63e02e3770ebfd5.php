

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid" style="margin-left: 6cm;">
    <div class="row">
        <div class="col-md-3 sidebar-container">
            <div class="panel panel-default">
                <div class="panel-heading"><h3>Add a User</h3></div>
                <div class="panel-body">
                    <?php echo Form::open(['route' => 'users.store', 'class' => 'form-horizontal']); ?>

               
                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('name', 'Name', ['class' => 'control-label']); ?>

                        <?php echo Form::text('name', old('name'), ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('name')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('email', 'Email', ['class' => 'control-label']); ?>

                        <?php echo Form::email('email', old('email'), ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('password', 'password', ['class' => 'control-label']); ?>

                        <?php echo Form::password('password', ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="form-group<?php echo e($errors->has('isadmin') ? ' has-error' : ''); ?>">
                        <?php echo Form::label('isadmin', 'Admin', ['class' => 'control-label']); ?>

                        <?php echo Form::select('isadmin', [1 => 'Yes', 0 => 'No'], old('isadmin'), ['class' => 'form-control', 'required' => 'required']); ?>

                        <?php if($errors->has('isadmin')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('isadmin')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    
                  


                        <br>
                        <div class="form-group">
                        <?php echo Form::submit('Add User', ['class' => 'btn btn-primary']); ?>

                        <a href="/users" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </div>
                        <?php echo Form::close(); ?>

                        </div>
                        </div>
                        </div>
                        </div>
                        
                        </div>
                        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/users/create.blade.php ENDPATH**/ ?>