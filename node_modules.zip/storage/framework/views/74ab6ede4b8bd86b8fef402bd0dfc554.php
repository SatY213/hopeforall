

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container" style="margin-left: 6cm;">
        <div class="row">
            <div class="col-md-12">
                <h3>Donations</h3>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Amount</th>
                                    <th>Date Of Donation</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($donation->name); ?></td>
                                    <td><?php echo e($donation->email); ?></td>
                                    <td><?php echo e($donation->amount); ?></td>
                                    <td><?php echo e($donation->created_at); ?></td>
                                    <td>
                                        <div style="display: flex;">
                                            <button type="button" class="btn btn-info mr-2" data-toggle="modal" data-target="#donation<?php echo e($donation->id); ?>">Detail</button>
                                            <div style="width: 10px;"></div>
                                            <form method="POST" action="<?php echo e(route('donation.destroy', $donation->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href="<?php echo e(route('donation.edit', $donation->id)); ?>" class="btn btn-primary">Edit</a>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                        
                                        <!-- Modal -->
                                        <div class="modal fade" id="donation<?php echo e($donation->id); ?>" tabindex="-1" role="dialog" aria-labelledby="donation<?php echo e($donation->id); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="donation<?php echo e($donation->id); ?>Label">Donation Details</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p><strong>Name:</strong> <?php echo e($donation->name); ?></p>
                                                        <p><strong>Email:</strong> <?php echo e($donation->email); ?></p>
                                                        <p><strong>Amount:</strong> <?php echo e($donation->amount); ?></p>
                                                        <p><strong>Message:</strong> <?php echo e($donation->message); ?></p>
                                                        <p><strong>Date Of Donation:</strong> <?php echo e($donation->created_at); ?></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                <!-- Donation Details Modal End -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="float-right">
                            <a href="<?php echo e(route('donation.create')); ?>" class="btn btn-success">Add Donation</a>
                            <a href="/dashboard" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </div>
                  
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/donation/index.blade.php ENDPATH**/ ?>