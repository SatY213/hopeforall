<!-- edit.blade.php -->


<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container style="margin-left: 6cm;"">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Edit Fee</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('fees.update', $fee->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="form-group">
                                <label for="member">Member</label>
                                <select class="form-control" id="member" name="member" required>
                                    <option value="">Select a member</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($member->name); ?>" <?php echo e($fee->member_id == $member->id ? 'selected' : ''); ?>>
                                            <?php echo e($member->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="amount">Amount</label>
                                <input type="number" class="form-control" id="amount" name="amount" value="<?php echo e($fee->amount); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="from">From</label>
                                <input type="date" class="form-control" id="from" name="from" value="<?php echo e($fee->from); ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="to">To</label>
                                <input type="date" class="form-control" id="to" name="to" value="<?php echo e($fee->to); ?>" required>
                            </div>
<br>
                            <button type="submit" class="btn btn-primary">Update</button>
                            <a href="/fees" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/fees/edit.blade.php ENDPATH**/ ?>