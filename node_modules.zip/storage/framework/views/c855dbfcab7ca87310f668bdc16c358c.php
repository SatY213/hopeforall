

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('include-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container" style="margin-left: 6cm;">
        <div class="row">
            <div class="col-md-12">
                <h3>Fees</h3>

                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Member</th>
                                    <th>Amount</th>
                                    <th>From</th>
                                    <th>To</th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($fee->member); ?></td>
                                    <td><?php echo e($fee->amount); ?></td>
                                    <td><?php echo e($fee->from); ?></td>
                                    <td><?php echo e($fee->to); ?></td>
                                    <td><?php echo e($fee->created_at); ?></td>
                                    <td>
                                        <div style="display: flex;">
                                            <button type="button" class="btn btn-info mr-2" data-toggle="modal" data-target="#fee<?php echo e($fee->id); ?>">Detail</button>
                                            <div style="width: 10px;"></div>
                                            <form method="POST" action="<?php echo e(route('fees.destroy', $fee->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <a href="<?php echo e(route('fees.edit', $fee->id)); ?>" class="btn btn-primary">Edit</a>
                                                <button type="submit" class="btn btn-danger">Delete</button>
                                            </form>
                                        </div>
                                        
                                        <!-- Modal -->
                                        <div class="modal fade" id="fee<?php echo e($fee->id); ?>" tabindex="-1" role="dialog" aria-labelledby="fee<?php echo e($fee->id); ?>Label" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="<?php echo e($fee->id); ?>Label">fee Details</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p><strong>Member:</strong> <?php echo e($fee->member); ?></p>
                                                        <p><strong>Amount:</strong> <?php echo e($fee->amount); ?></p>
                                                        <p><strong>From:</strong> <?php echo e($fee->from); ?></p>
                                                        <p><strong>to:</strong> <?php echo e($fee->to); ?></p>
                                                        <p><strong>Date Of Creation:</strong> <?php echo e($fee->created_at); ?></p>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                <!-- Fee Details Modal End -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="float-right">
                            <a href="<?php echo e(route('fees.create')); ?>" class="btn btn-success">Add Fee</a>
                            <a href="/dashboard" class="btn btn-outline-secondary float-right ml-2">Go Back</a>

                        </div>
                  
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/fees/index.blade.php ENDPATH**/ ?>